# Complete host measurement

Owner: Alexander Bleissem
Status: in_progress
Source: c31c1c87ec61ae56bdab6a0633f707df496aa66a; native measurement receipts in evidence/native-ci.json.

The owner requested autonomous implementation and correction while retaining the
87-percent gate. Root selects additional complete validation-host measurement.
The existing product inventory, native platform selection, diff base, thresholds
and absence of a baseline remain unchanged. The full static check retains tests
and host source.

Source analysis: tests/coverage.runsettings currently instruments the six product
libraries; codemetr-cover.json excludes examples. UnitTests and PlatformTests now
reference the actual matching host assembly. ScenarioRunner owns native state and
dispatches fourteen bounded offline scenarios plus the separate actual hour soak.
RecoveryProbeChild starts the assembly containing its implementation, so an
instrumented host reference can also supply owned child execution. No production
execution wrapper or new adapter abstraction is required.

scripts/Test-Coverage.ps1 owns the strict src-project inventory and complete native
product threshold. It must accept only explicitly registered additional validation
assemblies without counting test fixtures or host lines as shipped product lines.
It must require that declared validation assembly to be present. Codemetr Cover
then independently checks the expanded complete source inventory including all
examples, counting unreported source as zero. Both gates retain 87 percent; no
source is moved or excluded to pass.

Test sequence: first observe synthetic guard failures for a co-collected declared
host and for its missing report; retain the unchanged rejection of foreign modules
and below-threshold products even when host data is present. Archive the pre-Green
state. Expand collection, registration and full Cover scope, then measure before
adding tests. Exercise real native scenario owners with status, state creation and
lease-release assertions. Use measured uncovered members for remaining meaningful
boundary cases. No live credentials and no fake short replacement for the hour soak.

Acceptance: complete local and native Windows/Linux suites, both 87-percent gates,
zero unmeasured changed host files, full static CLI, package consumption and actual
published-host scenarios pass for one source hash. Review-ready PR status follows
that evidence. Original historical Windows causality and the explicitly bounded
SharpClaw integration claims remain governed by the existing plans.
