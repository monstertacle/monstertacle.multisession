using Monstertacle.Multisession.Contracts;

namespace Monstertacle.Multisession.ValidationHost;

// Serialized diagnostic payload, with no execution or resource-lifetime responsibility.
internal sealed record ValidationFailure(PublicError Error, FailureDetails? Details = null);
