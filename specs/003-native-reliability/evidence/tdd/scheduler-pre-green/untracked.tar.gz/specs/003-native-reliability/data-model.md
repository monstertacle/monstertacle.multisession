# Data model
No SQLite schema changes. Optional FailureDetails on public errors; existing positional error constructor remains compatible.
Executor state remains waiting/running/finished plus closed; cancelled waiting work must never reach its action. Cleanup completion means the connection owner has disposed the connection, not that remote provider work ended.
