# Tasks
Created: 2026-10-30T06:20:36Z
- [x] T001 Read source, CI failures, governance and current SharpClaw; record evidence before implementation.
- [x] T002 Specify behavior, architecture, contracts and acceptance.
- [ ] T003 Reproduce scheduling hypothesis outside repository and record measured result.
- [ ] T004 Add executable scheduler regression and archive observed behavioral Red.
- [ ] T005 Implement independently schedulable owned executor, preserving bounded FIFO/cancellation/disposal.
- [ ] T006 Add real safe-diagnostic/propagation/timeout regressions; archive Red.
- [ ] T007 Implement structured diagnostic normalization without changing acceptance certainty.
- [ ] T008 Test and fix validation report error preservation and sanitization.
- [ ] T009 Run full static metrics, native quality/Cover and package consumption.
- [ ] T010 Repeat native Windows scenarios and inspect safe diagnostics for any recurrence.
- [ ] T011 Commit/push reviewable work, bind native CI evidence, disposition all findings.
