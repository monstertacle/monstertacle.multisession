using System.Diagnostics;
using System.Text.Json;
using Monstertacle.Multisession.IntegrationTests.Fixtures;
using Xunit;

namespace Monstertacle.Multisession.IntegrationTests;

/// <summary>The serial SQLite executor must remain schedulable while unrelated managed workers are blocked.</summary>
public sealed class StoreSchedulerTests
{
    /// <summary>The single blocked worker is confined to a child, preserving the test runner's scheduler.</summary>
    [Fact]
    public async Task IdleStoreReadDoesNotDependOnAvailableManagedWorkers()
    {
        await using PrivateStoreDirectory parent = new();
        ProcessStartInfo start = new("dotnet");
        foreach (string argument in new[] { ValidationHostBuild.WorkerPath(), "--store-scheduler-probe", Path.Combine(parent.StateDirectory, "scheduler") })
        { start.ArgumentList.Add(argument); }
        ProbeProcessResult result = await ProbeProcess.RunAsync(start);
        Assert.True(result.ExitCode == 0, result.Output);
        using JsonDocument report = JsonDocument.Parse(result.Output);
        Assert.True(report.RootElement.GetProperty("IndependentStoreRead").GetBoolean());
    }
}
